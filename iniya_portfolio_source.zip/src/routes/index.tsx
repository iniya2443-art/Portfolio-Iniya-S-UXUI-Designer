import { createFileRoute } from "@tanstack/react-router";
import Header from "@/components/portfolio/Header";
import ThemeToggle from "@/components/portfolio/ThemeToggle";
import Hero from "@/components/portfolio/Hero";
import About from "@/components/portfolio/About";
import Education from "@/components/portfolio/Education";
import Skills from "@/components/portfolio/Skills";
import Projects from "@/components/portfolio/Projects";
import Contact from "@/components/portfolio/Contact";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Iniya S — UX/UI Designer" },
      {
        name: "description",
        content:
          "Portfolio of Iniya S, UX/UI Designer based in Chennai. Designing intuitive, user-centered digital experiences.",
      },
      { property: "og:title", content: "Iniya S — UX/UI Designer" },
      { property: "og:description", content: "Portfolio of Iniya S, UX/UI Designer based in Chennai." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="font-sans">
      <ThemeToggle />
      <Header />
      <Hero />
      <About />
      <Education />
      <Skills />
      <Projects />
      <Contact />
      <footer
        className="text-center py-12 border-t-2 opacity-65"
        style={{ borderColor: "var(--color-border)", background: "var(--gradient-tile)" }}
      >
        <p className="my-1 font-medium">© 2026 Iniya S. All rights reserved.</p>
        <p className="my-1 font-medium">Designed with purpose &amp; passion</p>
      </footer>
    </main>
  );
}
