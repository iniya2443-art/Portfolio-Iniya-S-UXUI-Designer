import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

const links = [
  { href: "#about", label: "About" },
  { href: "#education", label: "Education" },
  { href: "#skills", label: "Skills" },
  { href: "#projects", label: "Projects" },
  { href: "#contact", label: "Contact" },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleNav = (href: string) => {
    setOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <motion.header
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: "easeOut" }}
      className={`fixed top-0 inset-x-0 z-50 backdrop-blur-xl backdrop-saturate-150 transition-shadow duration-300 ${
        scrolled ? "shadow-[0_8px_32px_rgba(0,0,0,0.08)]" : "shadow-[0_4px_24px_rgba(0,0,0,0.04)]"
      }`}
      style={{
        background: "color-mix(in oklab, var(--color-background) 85%, transparent)",
        borderBottom: "1px solid var(--color-border)",
      }}
    >
      <nav className="max-w-[1200px] mx-auto flex items-center justify-between px-8 py-5">
        <button onClick={() => handleNav("#top")} className="relative text-2xl font-black tracking-tight text-primary">
          INIYA S
          <span className="absolute -bottom-1 left-0 h-[3px] w-[40%] rounded-full" style={{ background: "var(--gradient-bar)" }} />
        </button>

        <ul className="hidden md:flex items-center gap-12 list-none">
          {links.map((l) => (
            <li key={l.href}>
              <button
                onClick={() => handleNav(l.href)}
                className="story-link text-sm font-semibold uppercase tracking-wider opacity-80 hover:opacity-100 hover:text-primary transition-colors"
              >
                {l.label}
              </button>
            </li>
          ))}
        </ul>

        <button
          aria-label="Toggle menu"
          onClick={() => setOpen((o) => !o)}
          className="md:hidden flex flex-col gap-[5px] p-2"
        >
          <motion.span animate={{ rotate: open ? 45 : 0, y: open ? 8 : 0 }} className="block w-7 h-[3px] rounded bg-primary" />
          <motion.span animate={{ opacity: open ? 0 : 1 }} className="block w-7 h-[3px] rounded bg-primary" />
          <motion.span animate={{ rotate: open ? -45 : 0, y: open ? -8 : 0 }} className="block w-7 h-[3px] rounded bg-primary" />
        </button>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ duration: 0.4, ease: "easeOut" }}
            className="md:hidden fixed top-0 right-0 h-screen w-3/4 flex flex-col items-center justify-center gap-10 border-l shadow-2xl"
            style={{ background: "var(--color-background)", borderColor: "var(--color-border)" }}
          >
            {links.map((l, i) => (
              <motion.button
                key={l.href}
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 + i * 0.06 }}
                onClick={() => handleNav(l.href)}
                className="text-lg font-bold uppercase tracking-widest hover:text-primary transition-colors"
              >
                {l.label}
              </motion.button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
