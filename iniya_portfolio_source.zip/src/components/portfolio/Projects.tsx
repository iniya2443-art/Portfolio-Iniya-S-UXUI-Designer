import { motion } from "framer-motion";
import SectionHeader, { Highlight } from "./SectionHeader";
import gentlefitImg from "@/assets/project-gentlefit.png";
import cookedupImg from "@/assets/project-cookedup.png";
import seeyourtimeImg from "@/assets/project-seeyourtime.jpg";

const projects = [
  {
    href: "https://www.behance.net/gallery/238982033/GentleFit-For-beginners-Mood-based-kind-motivation/modules/1420541131",
    title: "GentleFit",
    desc: "A beginner-focused wellness and fitness app that empowers users to build consistent, healthy habits from home through mood-based, equipment-free routines.",
    tags: ["Mobile App", "Wellness", "Figma", "User Research"],
    accent: "from-[oklch(0.78_0.13_180)] to-[oklch(0.66_0.08_230)]",
    initials: "GF",
    image: gentlefitImg,
  },
  {
    href: "https://www.behance.net/gallery/235681093/CookedUp-ResipeDiscovery-Meal-Planning-Food-Delivery/modules/1420110075",
    title: "CookedUp",
    desc: "A Tamil Nadu-special food app that simplifies healthy eating through personalized meal plans, recipe discovery, and food delivery in one clean UI.",
    tags: ["Food & Lifestyle", "Mobile Design", "Prototyping", "Usability Testing"],
    accent: "from-[oklch(0.74_0.16_50)] to-[oklch(0.66_0.18_25)]",
    initials: "CU",
    image: cookedupImg,
  },
  {
    href: "https://www.behance.net/gallery/229453835/Task-Management-Time-Tracking-Productivity-Booster/modules/1314595613",
    title: "See Your Time",
    desc: "A task management and time tracking solution designed to improve productivity with clear task organization, integrated time tracking, and an intuitive interface.",
    tags: ["Productivity", "Time Tracking", "Mobile App", "Miro"],
    accent: "from-[oklch(0.66_0.15_290)] to-[oklch(0.56_0.12_260)]",
    initials: "SYT",
    image: seeyourtimeImg,
  },
];

export default function Projects() {
  return (
    <section id="projects" className="py-28">
      <div className="max-w-[1200px] mx-auto px-8">
        <SectionHeader tag="My Work">
          Featured <Highlight>Projects</Highlight>
        </SectionHeader>

        <div className="grid gap-10" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(340px, 1fr))" }}>
          {projects.map((p, i) => (
            <motion.a
              key={p.title}
              href={p.href}
              target="_blank"
              rel="noreferrer"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.7, delay: i * 0.12, ease: "easeOut" }}
              whileHover={{ y: -12 }}
              className="tilt-card top-accent block rounded-3xl overflow-hidden border-[1.5px] no-underline"
              style={{ background: "var(--gradient-tile)", borderColor: "var(--color-border)" }}
            >
              <div className={`relative aspect-[16/10] overflow-hidden bg-gradient-to-br ${p.accent}`}>
                <motion.img
                  src={p.image}
                  alt={`${p.title} project banner`}
                  loading="lazy"
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.6, ease: "easeOut" }}
                  className="absolute inset-0 w-full h-full object-cover"
                />
                <div
                  aria-hidden
                  className="absolute -inset-1 opacity-30 mix-blend-overlay animate-spin-slow pointer-events-none"
                  style={{
                    background:
                      "conic-gradient(from 0deg, transparent 0deg, rgba(255,255,255,0.35) 60deg, transparent 120deg)",
                  }}
                />
              </div>
              <div className="p-8 md:p-10">
                <h3 className="text-2xl mb-4 font-extrabold tracking-tight">{p.title}</h3>
                <p className="opacity-75 leading-[1.75] mb-7">{p.desc}</p>
                <div className="flex flex-wrap gap-2">
                  {p.tags.map((t) => (
                    <motion.span
                      key={t}
                      whileHover={{ y: -2 }}
                      className="px-4 py-1.5 rounded-full text-sm font-bold border text-primary"
                      style={{
                        background: "var(--gradient-tile-strong)",
                        borderColor: "rgb(var(--primary-rgb) / 0.2)",
                      }}
                    >
                      {t}
                    </motion.span>
                  ))}
                </div>
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
