import { motion } from "framer-motion";
import iniya from "@/assets/iniya.png";
import SectionHeader, { Highlight } from "./SectionHeader";

const stats = [
  { n: "2023", l: "Graduate" },
  { n: "1st Class", l: "with Distinction" },
  { n: "9 Months", l: "UX/UI Journey" },
  { n: "3", l: "Projects " },
];

const paragraphs = [
  "“I’m a UX/UI Designer with a background in Business Administration. I graduated with First Class with Distinction from Thiruvalluvar University, and my final-year project on Employee Retention helped me develop a deeper understanding of user behavior.",
  "About nine months ago, I discovered my passion for UX/UI design while exploring how apps and websites are created. This curiosity led me to pursue a comprehensive UX/UI design course, and I’ve been deeply committed to growing in this field ever since.",
  "I have completed three professional projects, each focused on solving real user problems through research, prototyping, and iterative design. My approach blends business strategy with user-centered design to create digital experiences that are both functional and visually engaging.",
];

export default function About() {
  return (
    <section id="about" className="py-28 relative overflow-hidden">
      {/* Animated background: gradient blobs + drifting UX/UI tool icons */}
      <div aria-hidden className="absolute inset-0 pointer-events-none -z-10">
        <div
          className="absolute -left-[10%] top-[10%] w-[500px] h-[500px] rounded-full blur-[80px] animate-float-blob opacity-60"
          style={{ background: "radial-gradient(circle, rgb(var(--primary-rgb) / 0.18) 0%, transparent 70%)" }}
        />
        <div
          className="absolute -right-[10%] bottom-[5%] w-[550px] h-[550px] rounded-full blur-[90px] animate-float-blob-rev opacity-60"
          style={{ background: "radial-gradient(circle, rgb(var(--secondary-rgb) / 0.18) 0%, transparent 70%)" }}
        />

        {/* Figma-style dots */}
        <div className="absolute left-[6%] top-[18%] flex flex-col gap-1 animate-drift-1 opacity-50">
          <div className="flex gap-1">
            <span className="w-4 h-4 rounded-full" style={{ background: "rgb(var(--primary-rgb) / 0.6)" }} />
            <span className="w-4 h-4 rounded-full" style={{ background: "rgb(var(--secondary-rgb) / 0.7)" }} />
          </div>
          <div className="flex gap-1">
            <span className="w-4 h-4 rounded-full" style={{ background: "rgb(var(--primary-rgb) / 0.5)" }} />
            <span className="w-4 h-4 rounded-full" style={{ background: "rgb(var(--secondary-rgb) / 0.6)" }} />
          </div>
        </div>

        {/* Cursor / pointer */}
        <svg className="absolute right-[8%] top-[14%] w-10 h-10 animate-drift-2 opacity-40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: "var(--color-primary)" }}>
          <path d="M3 3l7 17 2-7 7-2z" />
        </svg>

        {/* Pen tool / star */}
        <svg className="absolute left-[10%] bottom-[20%] w-12 h-12 animate-drift-3 opacity-40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" style={{ color: "var(--color-primary)" }}>
          <path d="M12 2l3 7h7l-5.5 4.5L18 21l-6-4-6 4 1.5-7.5L2 9h7z" />
        </svg>

        {/* Artboard frame */}
        <div className="absolute right-[6%] bottom-[18%] w-16 h-12 rounded-md border-2 animate-drift-1 opacity-40" style={{ borderColor: "rgb(var(--primary-rgb) / 0.6)" }} />

        {/* Color swatches */}
        <div className="absolute right-[20%] top-[55%] flex gap-1.5 animate-drift-2 opacity-50">
          <span className="w-5 h-5 rounded" style={{ background: "rgb(var(--primary-rgb) / 0.7)" }} />
          <span className="w-5 h-5 rounded" style={{ background: "rgb(var(--secondary-rgb) / 0.8)" }} />
          <span className="w-5 h-5 rounded" style={{ background: "rgb(var(--primary-rgb) / 0.4)" }} />
        </div>

        {/* Layers icon */}
        <svg className="absolute left-[45%] top-[8%] w-10 h-10 animate-drift-3 opacity-35" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" style={{ color: "var(--color-primary)" }}>
          <path d="M12 2l10 6-10 6L2 8z" />
          <path d="M2 14l10 6 10-6" />
        </svg>

        {/* Rotated square */}
        <div className="absolute left-[35%] bottom-[10%] w-14 h-14 rotate-12 border-2 rounded-lg animate-drift-1 opacity-35" style={{ borderColor: "rgb(var(--secondary-rgb) / 0.7)" }} />
      </div>

      <div className="max-w-[1200px] mx-auto px-8 relative">
        <SectionHeader tag="About Me">
          Designing with <Highlight>empathy &amp; purpose</Highlight>
        </SectionHeader>

        <div className="grid md:grid-cols-2 gap-20 items-center">
          <motion.div
            initial={{ opacity: 0, x: -40, rotate: -2 }}
            whileInView={{ opacity: 1, x: 0, rotate: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.9, ease: "easeOut" }}
            className="relative text-center"
          >
            <div
              aria-hidden
              className="absolute left-1/2 -translate-x-1/2 -top-5 -bottom-5 w-[calc(100%-40px)] max-w-[380px] rounded-3xl -z-10 blur-3xl"
              style={{ background: "var(--gradient-tile-strong)" }}
            />
            <motion.img
              whileHover={{ scale: 1.03, y: -8 }}
              transition={{ duration: 0.5, ease: "easeOut" }}
              src={iniya}
              alt="Iniya S - UX/UI Designer"
              className="w-full max-w-[420px] border-primary aspect-[3/4] text-center mx-[21px] border-4 border-slate-400 object-fill"
              style={{ borderRadius: "50%", boxShadow: "var(--shadow-lift)" }}
              
            />
          </motion.div>

          <div>
            {paragraphs.map((p, i) => (
              <motion.p
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-80px" }}
                transition={{ duration: 0.6, delay: i * 0.15 }}
                className="opacity-85 leading-[1.9] mb-7 text-base md:text-[1.05rem]"
              >
                {p}
              </motion.p>
            ))}

            <div className="grid grid-cols-2 gap-7 mt-10">
              {stats.map((s, i) => (
                <motion.div
                  key={s.l}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ duration: 0.5, delay: i * 0.08 }}
                  whileHover={{ y: -8 }}
                  className="tilt-card top-accent rounded-2xl p-9 text-center border-[1.5px]"
                  style={{
                    background: "var(--gradient-tile)",
                    borderColor: "var(--color-border)",
                    boxShadow: "var(--shadow-soft)",
                  }}
                >
                  <span className="block text-[2.5rem] font-black text-primary mb-2 leading-none">{s.n}</span>
                  <span className="block text-sm uppercase tracking-wider opacity-65 font-bold">{s.l}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
