import { motion } from "framer-motion";
import SectionHeader, { Highlight } from "./SectionHeader";

export default function Education() {
  return (
    <section id="education" className="py-28">
      <div className="max-w-[1200px] mx-auto px-8">
        <SectionHeader tag="Education">
          Academic <Highlight>Background</Highlight>
        </SectionHeader>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          whileHover={{ y: -4 }}
          className="tilt-card top-accent max-w-[950px] mx-auto rounded-3xl p-8 md:p-14 border-[1.5px]"
          style={{ background: "var(--gradient-tile)", borderColor: "var(--color-border)" }}
        >
          <div className="text-3xl md:text-[2.2rem] font-black mb-2 tracking-tight">Bachelor of Business Administration (BBA)</div>
          <div className="text-xl md:text-[1.4rem] mb-2 opacity-85 font-semibold">Thiruvalluvar University</div>
          <div className="text-base md:text-[1.05rem] opacity-65 mb-8 font-semibold">2020 - 2023</div>

          <motion.div
            whileHover={{ scale: 1.03 }}
            className="inline-block text-white px-8 py-3 font-extrabold mb-10 rounded-xl"
            style={{ background: "var(--gradient-btn)", boxShadow: "var(--shadow-glow)" }}
          >
            First Class with Distinction
          </motion.div>

          <div className="mt-10 pt-10 border-t-2" style={{ borderColor: "var(--color-border)" }}>
            <h4 className="text-2xl mb-5 text-primary font-extrabold">Final Year Project</h4>
            <p className="opacity-85 leading-[1.9] mb-5">
              <strong>Employee Retention: Strategies for Organizational Success</strong>
            </p>
            <p className="opacity-85 leading-[1.9] mb-5">
              Conducted comprehensive research analyzing factors that influence employee satisfaction, engagement, and organizational
              commitment. This project laid the foundation for understanding user behavior and psychology—principles that directly
              translate to creating user-centered design solutions.
            </p>

            <h4 className="text-2xl mb-5 mt-10 text-primary font-extrabold">UX/UI Design Certification</h4>
            <p className="opacity-85 leading-[1.9] mb-5">
              Completed intensive UX/UI Design course covering user research, wireframing, prototyping, visual design, and usability
              testing. Applied learned principles across 3 real-world projects.
            </p>
            <motion.a
              whileHover={{ y: -3 }}
              whileTap={{ scale: 0.97 }}
              href="https://v2.zenclass.in/certificateDownload/AvV7QFPwkgghjCjn?download=true"
              target="_blank"
              rel="noreferrer"
              className="btn-shine inline-block mt-6 px-8 py-4 rounded-xl text-white font-bold"
              style={{ background: "var(--gradient-btn)", boxShadow: "var(--shadow-glow)" }}
            >
              View Certificate
            </motion.a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
