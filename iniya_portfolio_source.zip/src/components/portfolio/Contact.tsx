import { motion } from "framer-motion";
import SectionHeader, { Highlight } from "./SectionHeader";

const items = [
  { icon: "📍", text: "Chennai, Tamil Nadu, India" },
  { icon: "📧", text: "iniya2443@gmail.com", href: "mailto:iniya2443@gmail.com" },
  { icon: "💼", text: "LinkedIn Profile", href: "https://www.linkedin.com/in/iniya-s-24ai04/" },
];

const socials = [
  { label: "in", title: "LinkedIn", href: "https://www.linkedin.com/in/iniya-s-24ai04/" },
  { label: "Be", title: "Behance", href: "https://www.behance.net/iniyas1" },
  { label: "Dr", title: "Dribbble", href: "https://dribbble.com/account/profile" },
  { label: "✉", title: "Email", href: "mailto:iniya2443@gmail.com" },
];

export default function Contact() {
  return (
    <section id="contact" className="py-28">
      <div className="max-w-[1200px] mx-auto px-8">
        <SectionHeader tag="Get In Touch">
          Let's <Highlight>collaborate</Highlight>
        </SectionHeader>

        <div className="max-w-[850px] mx-auto text-center">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6 }}
            className="text-lg md:text-xl mb-14 opacity-85 leading-[1.9]"
          >
            I'm always interested in discussing new UX/UI projects, design collaborations, and opportunities to create meaningful user
            experiences.
          </motion.p>

          <div className="flex flex-col gap-7 mb-14">
            {items.map((it, i) => {
              const inner = (
                <>
                  <span className="text-2xl">{it.icon}</span>
                  <span className="font-semibold">{it.text}</span>
                </>
              );
              return (
                <motion.div
                  key={it.text}
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ duration: 0.5, delay: i * 0.1 }}
                  whileHover={{ x: 8 }}
                  className="flex items-center justify-center gap-5 p-5 rounded-2xl border"
                  style={{ background: "var(--gradient-tile)", borderColor: "var(--color-border)" }}
                >
                  {it.href ? (
                    <a href={it.href} target={it.href.startsWith("http") ? "_blank" : undefined} rel="noreferrer" className="flex items-center gap-5 hover:text-primary transition-colors">
                      {inner}
                    </a>
                  ) : (
                    <div className="flex items-center gap-5">{inner}</div>
                  )}
                </motion.div>
              );
            })}
          </div>

          <div className="flex justify-center gap-6 mt-14">
            {socials.map((s, i) => (
              <motion.a
                key={s.title}
                href={s.href}
                target="_blank"
                rel="noreferrer"
                title={s.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                whileHover={{ y: -8, rotate: 6 }}
                whileTap={{ scale: 0.95 }}
                className="w-16 h-16 rounded-2xl border-2 flex items-center justify-center font-extrabold text-xl hover:text-white transition-colors"
                style={{ background: "var(--gradient-tile)", borderColor: "var(--color-border)" }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLElement).style.background = "var(--gradient-btn)";
                  (e.currentTarget as HTMLElement).style.borderColor = "var(--color-primary)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLElement).style.background = "var(--gradient-tile)";
                  (e.currentTarget as HTMLElement).style.borderColor = "var(--color-border)";
                }}
              >
                {s.label}
              </motion.a>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
