import { motion } from "framer-motion";
import type { ReactNode } from "react";

export default function SectionHeader({ tag, children }: { tag: string; children: ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.7, ease: "easeOut" }}
      className="text-center mb-20"
    >
      <p
        className="inline-block px-6 py-2 rounded-full text-sm font-extrabold uppercase tracking-[0.2em] text-primary border"
        style={{ background: "var(--gradient-tile)", borderColor: "rgb(var(--primary-rgb) / 0.15)" }}
      >
        {tag}
      </p>
      <h2 className="font-black mt-4 leading-tight tracking-tight" style={{ fontSize: "clamp(2.5rem, 6vw, 3.5rem)", letterSpacing: "-0.03em" }}>
        {children}
      </h2>
    </motion.div>
  );
}

export function Highlight({ children }: { children: ReactNode }) {
  return <span className="animate-shimmer">{children}</span>;
}
