import { motion, type Variants } from "framer-motion";

const socials = [
  {
    href: "https://www.linkedin.com/in/iniya-s-24ai04/",
    title: "LinkedIn",
    path: "M6.94 5a2 2 0 1 1-4-.002 2 2 0 0 1 4 .002zM7 8.48H3V21h4V8.48zm6.32 0H9.34V21h3.94v-6.57c0-3.66 4.77-4 4.77 0V21H22v-7.93c0-6.17-7.06-5.94-8.72-2.91l.04-1.68z",
  },
  {
    href: "https://dribbble.com/account/profile",
    title: "Dribbble",
    path: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10c5.51 0 10-4.48 10-10S17.51 2 12 2zm6.605 4.61a8.502 8.502 0 0 1 1.93 5.314c-.281-.054-3.101-.629-5.943-.271-.065-.141-.12-.293-.184-.445a25.416 25.416 0 0 0-.564-1.236c3.145-1.28 4.577-3.124 4.761-3.362zM12 3.475c2.17 0 4.154.813 5.662 2.148-.152.216-1.443 1.941-4.48 3.08-1.399-2.57-2.95-4.675-3.189-5A8.687 8.687 0 0 1 12 3.475zm-3.633.803a53.896 53.896 0 0 1 3.167 4.935c-3.992 1.063-7.517 1.04-7.896 1.04a8.581 8.581 0 0 1 4.729-5.975zM3.453 12.01v-.26c.37.01 4.512.065 8.775-1.215.25.477.477.965.694 1.453-.109.033-.228.065-.336.098-4.404 1.42-6.747 5.303-6.942 5.629a8.522 8.522 0 0 1-2.19-5.705zM12 20.547a8.482 8.482 0 0 1-5.239-1.8c.152-.315 1.888-3.656 6.703-5.337.022-.01.033-.01.054-.022a35.318 35.318 0 0 1 1.823 6.475 8.4 8.4 0 0 1-3.341.684zm4.761-1.465c-.086-.52-.542-3.015-1.659-6.084 2.679-.423 5.022.271 5.314.369a8.468 8.468 0 0 1-3.655 5.715z",
  },
  {
    href: "https://github.com/iniya2443-art",
    title: "GitHub",
    path: "M12 2C6.475 2 2 6.475 2 12a9.994 9.994 0 0 0 6.838 9.488c.5.087.687-.213.687-.476 0-.237-.013-1.024-.013-1.862-2.512.463-3.162-.612-3.362-1.175-.113-.288-.6-1.175-1.025-1.413-.35-.187-.85-.65-.013-.662.788-.013 1.35.725 1.538 1.025.9 1.512 2.338 1.087 2.912.825.088-.65.35-1.087.638-1.337-2.225-.25-4.55-1.113-4.55-4.938 0-1.088.387-1.987 1.025-2.688-.1-.25-.45-1.275.1-2.65 0 0 .837-.262 2.75 1.026a9.28 9.28 0 0 1 2.5-.338c.85 0 1.7.112 2.5.337 1.912-1.3 2.75-1.024 2.75-1.024.55 1.375.2 2.4.1 2.65.637.7 1.025 1.587 1.025 2.687 0 3.838-2.337 4.688-4.562 4.938.362.312.675.912.675 1.85 0 1.337-.013 2.412-.013 2.75 0 .262.188.574.688.474A10.016 10.016 0 0 0 22 12c0-5.525-4.475-10-10-10z",
  },
  {
    href: "https://docs.google.com/document/d/14czOTCRydLVge9KY0Bptkr8_mIpSWWV9/edit?usp=sharing&ouid=115049169216024584746&rtpof=true&sd=true",
    title: "Resume",
    path: "M13 12h7v1.5h-7zm0-2.5h7V11h-7zm0 5h7V16h-7zM12 3v3H9v1.5h3v3h1.5v-3h3V6h-3V3zM4 3h5v2H4v14h14v-5h2v5a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5c0-1.1.9-2 2-2z",
  },
];

const container: Variants = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.12, delayChildren: 0.1 } },
};
const item: Variants = {
  hidden: { opacity: 0, y: 30 },
  show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: "easeOut" } },
};

export default function Hero() {
  return (
    <section id="top" className="relative min-h-screen flex items-center justify-center pt-28 overflow-hidden">
      {/* Conic halo */}
      <div
        aria-hidden
        className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[120vmin] h-[120vmin] rounded-full opacity-30 dark:opacity-25 animate-spin-slow pointer-events-none"
        style={{
          background:
            "conic-gradient(from 0deg, rgb(var(--primary-rgb) / 0.35), transparent 25%, rgb(var(--secondary-rgb) / 0.3) 50%, transparent 75%, rgb(var(--primary-rgb) / 0.35))",
          filter: "blur(60px)",
          maskImage: "radial-gradient(circle, black 40%, transparent 70%)",
        }}
      />

      {/* Background blobs */}
      <div
        aria-hidden
        className="absolute -left-[5%] top-[10%] w-[600px] h-[600px] rounded-full blur-[60px] animate-float-blob"
        style={{ background: "radial-gradient(circle, rgb(var(--primary-rgb) / 0.22) 0%, transparent 70%)" }}
      />
      <div
        aria-hidden
        className="absolute -right-[5%] bottom-[10%] w-[700px] h-[700px] rounded-full blur-[80px] animate-float-blob-rev"
        style={{ background: "radial-gradient(circle, rgb(var(--secondary-rgb) / 0.2) 0%, transparent 70%)" }}
      />

      {/* Animated background marquee text */}
      <div aria-hidden className="absolute inset-0 flex flex-col justify-center gap-12 pointer-events-none overflow-hidden z-0">
        <div className="whitespace-nowrap font-black tracking-tight opacity-[0.06] animate-marquee-ltr" style={{ fontSize: "clamp(4rem, 14vw, 12rem)", lineHeight: 1 }}>
          Iniya UX/UI Designer • Iniya UX/UI Designer • Iniya UX/UI Designer • Iniya UX/UI Designer •
        </div>
        <div className="whitespace-nowrap font-black tracking-tight opacity-[0.05] animate-marquee-rtl" style={{ fontSize: "clamp(4rem, 14vw, 12rem)", lineHeight: 1 }}>
          Iniya UX/UI Designer • Iniya UX/UI Designer • Iniya UX/UI Designer • Iniya UX/UI Designer •
        </div>
      </div>

      {/* Subtle grid */}
      <div
        aria-hidden
        className="absolute inset-0 opacity-[0.04] pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(var(--color-foreground) 1px, transparent 1px), linear-gradient(90deg, var(--color-foreground) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
          maskImage: "radial-gradient(ellipse at center, black 30%, transparent 70%)",
        }}
      />

      {/* Floating geometric shapes */}
      <div aria-hidden className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Ring */}
        <div
          className="absolute left-[8%] top-[18%] w-24 h-24 rounded-full border-2 animate-drift-1"
          style={{ borderColor: "rgb(var(--primary-rgb) / 0.35)" }}
        />
        {/* Solid circle */}
        <div
          className="absolute right-[10%] top-[24%] w-16 h-16 rounded-full animate-drift-2"
          style={{ background: "rgb(var(--secondary-rgb) / 0.35)", filter: "blur(2px)" }}
        />
        {/* Square (rotated) */}
        <div
          className="absolute left-[14%] bottom-[18%] w-20 h-20 rotate-45 animate-drift-3"
          style={{
            background: "linear-gradient(135deg, rgb(var(--primary-rgb) / 0.25), rgb(var(--secondary-rgb) / 0.15))",
            borderRadius: "8px",
          }}
        />
        {/* Triangle */}
        <div
          className="absolute right-[14%] bottom-[22%] w-0 h-0 animate-drift-1"
          style={{
            borderLeft: "28px solid transparent",
            borderRight: "28px solid transparent",
            borderBottom: "48px solid rgb(var(--primary-rgb) / 0.30)",
          }}
        />
        {/* Small ring */}
        <div
          className="absolute right-[28%] top-[60%] w-12 h-12 rounded-full border-2 animate-drift-2"
          style={{ borderColor: "rgb(var(--secondary-rgb) / 0.45)" }}
        />
        {/* Plus sign */}
        <div className="absolute left-[40%] top-[12%] w-10 h-10 animate-drift-3">
          <span className="absolute left-1/2 top-0 bottom-0 -translate-x-1/2 w-[3px]" style={{ background: "rgb(var(--primary-rgb) / 0.4)" }} />
          <span className="absolute top-1/2 left-0 right-0 -translate-y-1/2 h-[3px]" style={{ background: "rgb(var(--primary-rgb) / 0.4)" }} />
        </div>
      </div>

      {/* Sparkle particles */}
      <div aria-hidden className="absolute inset-0 pointer-events-none overflow-hidden">
        {[
          { l: "12%", t: "22%", d: "0s", s: 6 },
          { l: "82%", t: "18%", d: "1.2s", s: 4 },
          { l: "68%", t: "78%", d: "2.4s", s: 8 },
          { l: "22%", t: "72%", d: "0.6s", s: 5 },
          { l: "48%", t: "12%", d: "1.8s", s: 4 },
          { l: "92%", t: "55%", d: "3s", s: 6 },
          { l: "8%", t: "48%", d: "2.1s", s: 5 },
        ].map((p, i) => (
          <span
            key={i}
            className="absolute rounded-full bg-primary animate-twinkle"
            style={{ left: p.l, top: p.t, width: p.s, height: p.s, animationDelay: p.d, boxShadow: "0 0 12px rgb(var(--primary-rgb) / 0.8)" }}
          />
        ))}
      </div>

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="relative z-10 text-center max-w-5xl mx-6 px-6 md:px-14 py-14 md:py-20"
      >
        <motion.div
          variants={item}
          whileHover={{ y: -2 }}
          className="inline-flex items-center gap-2 px-7 py-3 rounded-full border-[1.5px] mb-10 font-bold text-sm tracking-wide"
          style={{
            background: "var(--gradient-tile)",
            borderColor: "rgb(var(--primary-rgb) / 0.25)",
            color: "var(--color-primary)",
            boxShadow: "var(--shadow-soft)",
          }}
        >
          <span className="w-[9px] h-[9px] rounded-full bg-primary animate-pulse-ring" />
          Available for UX/UI Projects
        </motion.div>

        <motion.h1
          variants={item}
          className="font-black leading-[1.05] tracking-tight mb-6"
          style={{ fontSize: "clamp(3.5rem, 11vw, 7rem)", letterSpacing: "-0.04em" }}
        >
          Hi, I'm{" "}
          <span className="relative inline-block align-baseline">
            <span className="inline-flex">
              {"Iniya S".split("").map((ch, i) => (
                <motion.span
                  key={i}
                  className="inline-block animate-shimmer"
                  initial={{ y: 80, opacity: 0, rotate: -15 }}
                  animate={{ y: [0, -8, 0], opacity: 1, rotate: 0 }}
                  transition={{
                    y: { duration: 2.4, repeat: Infinity, ease: "easeInOut", delay: 1 + i * 0.15 },
                    opacity: { duration: 0.5, delay: 0.4 + i * 0.08 },
                    rotate: { type: "spring", stiffness: 200, damping: 12, delay: 0.4 + i * 0.08 },
                  }}
                  whileHover={{ scale: 1.2, rotate: [-5, 5, 0], transition: { duration: 0.4 } }}
                  style={{ transformOrigin: "center bottom" }}
                >
                  {ch === " " ? "\u00A0" : ch}
                </motion.span>
              ))}
            </span>
            <motion.span
              aria-hidden
              className="absolute left-0 right-0 -bottom-2 h-[6px] rounded-full"
              style={{ background: "var(--gradient-bar)", transformOrigin: "left" }}
              initial={{ scaleX: 0 }}
              animate={{ scaleX: [0, 1, 1, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay: 2 }}
            />
          </span>
        </motion.h1>

        <motion.p variants={item} className="font-semibold mb-8 opacity-90" style={{ fontSize: "clamp(1.4rem, 3.5vw, 2.2rem)" }}>
          UX/UI Designer
        </motion.p>

        <motion.p
          variants={item}
          className="max-w-3xl mx-auto mb-14 opacity-75 leading-[1.85]"
          style={{ fontSize: "clamp(1.05rem, 1.8vw, 1.25rem)" }}
        >
          I design intuitive, user-centered digital experiences that bridge business goals with user needs. With a foundation in
          Business Administration and a passion for design thinking, I transform complex problems into elegant, accessible solutions
          that users love.
        </motion.p>

        <motion.div variants={item} className="flex justify-center gap-5 flex-wrap mb-14">
          <motion.a
            whileHover={{ y: -4 }}
            whileTap={{ scale: 0.97 }}
            href="https://www.behance.net/iniyas1"
            target="_blank"
            rel="noreferrer"
            className="btn-shine px-12 py-4 rounded-2xl text-white font-bold text-base"
            style={{ background: "var(--gradient-btn)", boxShadow: "var(--shadow-glow)" }}
          >
            View My Work
          </motion.a>
          <motion.a
            whileHover={{ y: -4 }}
            whileTap={{ scale: 0.97 }}
            href="mailto:iniya2443@gmail.com"
            className="px-12 py-4 rounded-2xl font-bold text-base border-2 transition-colors"
            style={{ borderColor: "var(--color-border)", background: "var(--gradient-tile)" }}
          >
            Get in Touch
          </motion.a>
        </motion.div>

        <motion.div variants={item} className="flex justify-center gap-5">
          {socials.map((s) => (
            <motion.a
              key={s.title}
              whileHover={{ y: -4, scale: 1.06 }}
              whileTap={{ scale: 0.95 }}
              href={s.href}
              target="_blank"
              rel="noreferrer"
              title={s.title}
              className="w-12 h-12 rounded-xl border-[1.5px] flex items-center justify-center hover:text-primary hover:border-primary transition-colors"
              style={{ background: "var(--gradient-tile)", borderColor: "var(--color-border)" }}
            >
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" className="w-[22px] h-[22px] fill-current">
                <path d={s.path} />
              </svg>
            </motion.a>
          ))}
        </motion.div>

        <motion.div
          variants={item}
          className="mt-20 flex justify-center"
        >
          <div className="w-7 h-11 rounded-full border-2 flex items-start justify-center p-1.5" style={{ borderColor: "var(--color-border)" }}>
            <span className="w-1.5 h-2.5 rounded-full bg-primary animate-scroll-bob" />
          </div>
        </motion.div>
      </motion.div>
    </section>
  );
}
