import { motion } from "framer-motion";
import SectionHeader, { Highlight } from "./SectionHeader";

const groups = [
  { title: "UX Design", items: ["User Research & Analysis", "Wireframing & Prototyping", "Information Architecture", "Usability Testing", "User Journey Mapping"] },
  { title: "UI Design", items: ["Visual Design", "Design Systems", "Responsive Design", "Interaction Design", "Brand Identity"] },
  { title: "Design Tools", items: ["Figma", "Miro", "Adobe XD", "Adobe Photoshop", "Adobe Illustrator"] },
];

export default function Skills() {
  return (
    <section id="skills" className="py-28">
      <div className="max-w-[1200px] mx-auto px-8">
        <SectionHeader tag="Core Competencies">
          Skills &amp; <Highlight>Expertise</Highlight>
        </SectionHeader>

        <div className="grid gap-10" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))" }}>
          {groups.map((g, i) => (
            <motion.div
              key={g.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.6, delay: i * 0.1, ease: "easeOut" }}
              whileHover={{ y: -6 }}
              className="tilt-card top-accent rounded-3xl p-8 md:p-10 border-[1.5px]"
              style={{ background: "var(--gradient-tile)", borderColor: "var(--color-border)" }}
            >
              <h3 className="text-2xl mb-7 font-extrabold">{g.title}</h3>
              <ul className="list-none">
                {g.items.map((s, j) => (
                  <motion.li
                    key={s}
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: i * 0.08 + j * 0.05 }}
                    className="skill-item py-3 opacity-85 font-medium"
                  >
                    {s}
                  </motion.li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
